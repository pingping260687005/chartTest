import { element } from 'protractor';
import { ReadFileService } from './../shared/read-file.service';
import { Component, OnInit } from '@angular/core';
import * as G2 from '@antv/g2';
import * as c3 from 'c3';
import * as d3 from "d3";
@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css']
})
export class ChartComponent implements OnInit {
  private chart;
  private dv;
  constructor(private readFileService: ReadFileService) { }

  ngOnInit() {
    //var _DataSet = G2.DataSet, DataView = _DataSet.DataView;
    this.readFileService.readFile((data: ICustomer[]) => {
      //this.handleData(data);

      // this.drawChart(data); // draw chart

      /*var o = [];
      for (var i = 0, length = data.length; i < length; i++) {
        let char = data[i];
        let obj = o.find(obj => {
          return obj.hasOwnProperty(char.department)
          //return obj[department] ===  char.department
        });
        if (obj) {
          obj[char.department]++;
        } else {
          o.push({ [char.department]: 1 });
        }
      }
      let all = [];
      o.forEach(x => {
        let c = [];
        for (let i in x) {
          c.push(i);
          c.push(x[i]);
          break;
        }
        all.push(c);
      });
      console.log(all); */
    let all = [];
     data.forEach(customer=>{
      let deptObj = all.find(obj=>obj[0]===customer.department);
      if (deptObj) {
        deptObj.push(1);
      }else{
        deptObj =[];
        deptObj.push(customer.department);
        deptObj.push(1);
        all.push(deptObj);
      }
     
     });

      this.drawChart2(all);
    });
  }

  private drawChart2(data) {
    var chart = c3.generate({
      bindto: '#c1',
      data: {
        // iris data from R
        columns: data,
        type: 'pie',
        onmouseover: function (d, element) {
          alert("ddd");
        },
        onclick: function () {
          alert("click");
        }
      },
      pie: {
        label: {
          show: true,
          format: function (value: number, ratio: number, id: string) {
            return id + ":    " + ratio * 100 + "% ";
          }
        }
      },

      legend: {
        show: true
      },
      size: {
        width: 600,
        height: 600
      },
      tooltip: {
        /*format:  (value: any, ratio: number, id: string, index: number) => {
           return "ddd";
         }*/
      }
    });
    // legend
     /*d3.select('#c1').insert('div', '.chart').attr('class', 'legend').selectAll('span')
      .data(['data1', 'data2', 'data3'])
    .enter().append('span')
      .attr('data-id', function (id) { return id; })
      .html(function (id) { return id; })
      .each(function (id) {
          d3.select(this).style('background-color', chart.color(id));
      })
      .on('mouseover', function (id) {
          chart.focus(id);
      })
      .on('mouseout', function (id) {
          chart.revert();
      })
      .on('click', function (id) {
          chart.toggle(id);
      });
   
   setTimeout(function () {
      chart.load({
        columns: [
          ["肿瘤科", 5],
          ["呼吸内科", 2],
          ["胸外科", 2],
          ["泌尿科", 1]
        ]
      });
    }, 1500); */
 
  }
}
